#ifdef NETWORK
extern char *netplaynick;
extern char *netplayhost;
extern char *netpassword;
extern char *netgamekey;
extern int tport;
extern int netlocalplayers;

#endif
