void hq3x_32( unsigned char * pIn, unsigned char * pOut, int Xres, int Yres, int BpL);
int hq3x_InitLUTs(void);
void hq3x_Kill(void);

