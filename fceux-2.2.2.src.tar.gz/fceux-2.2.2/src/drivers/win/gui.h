void ShowCursorAbs(int set_visible);
int BrowseForFolder(HWND hParent, const char *htext, char *buf);
void CenterWindow(HWND hwndDlg);
void CenterWindowOnScreen(HWND hwnd);
