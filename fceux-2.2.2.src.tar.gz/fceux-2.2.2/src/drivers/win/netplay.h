extern CFGSTRUCT NetplayConfig[];
