#ifndef WIN_DIRECTORIES_H
#define WIN_DIRECTORIES_H

void ConfigDirectories();

#endif
