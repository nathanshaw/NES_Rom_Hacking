#include "types.h"

void FCEU_WriteWaveData(int32 *Buffer, int Count);
int FCEUI_EndWaveRecord();
