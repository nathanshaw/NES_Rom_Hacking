//this should be overridden with one generated in userconfig
//but it is here just in case to prevent compiler errors

#define SVN_REV 0
#define SVN_REV_STR "0"