This .hnd files are used to create documentation.
Made with HelpNDoc v3.0 Freeware Version.


After compiling the docs into CHM/HTML format, you should do the following:

* put fceux.chm to \fceu\trunk\output\
* put html version of fceux.hnd to \web\help\

* put taseditor.chm to \fceu\trunk\output\
* put html version of taseditor.hnd to \web\help\taseditor\

